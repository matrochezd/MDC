package com.example.quizapp;

public class QuestionAnswer {
    public static String question[] ={
            "What does 'HTTP' stand for in a web address?",
            "In computing, what is 'RAM' short for?",
            "Which of these is not a programming language?",
            "What is the name of the first computer programmer?",
            "Which company developed the video game 'Minecraft'?"

    };

    public static String choices[][] ={
            {"HyperText Transfer Protocol", "HyperText Transmission Protocol","Hyperlink Text Transfer Protocol", "Hyperlink Transfer Text Protocol"},
            {"Readily Available Memory", "Running Application Memory", "Random Access Memory", "Rapid Allocation Module"},
            {"Ruby", "Python", "Emerald", "Java"},
            {"Ada Lovelace", "Grace Hopper", "Alan Turing", "Charles Babbage"},
            {"Epic Games", "Mojang", "Blizzard Entertainment", "Electronic Arts"}

    };

    public static String correctAnswers[] ={
            "HyperText Transfer Protocol",
            "Random Access Memory",
            "Emerald",
            "Ada Lovelace",
            "Mojang"

    };

}
